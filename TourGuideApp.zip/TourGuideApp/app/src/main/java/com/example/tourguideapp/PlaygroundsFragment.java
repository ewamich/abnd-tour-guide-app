package com.example.tourguideapp;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ListView;

import androidx.fragment.app.Fragment;

import java.util.ArrayList;

public class PlaygroundsFragment extends Fragment {

    public PlaygroundsFragment() {

    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
        View rootView = inflater.inflate(R.layout.places_list, container, false
        );

        //create words arrayList
        final ArrayList<Place> place = new ArrayList<Place>();
        place.add(new Place(getString(R.string.playground_name1), "weṭeṭṭi", R.drawable.ic_launcher_background, getString(R.string.playground_description1)));
        place.add(new Place(getString(R.string.playground_name2), "weṭeṭṭi",  R.drawable.ic_launcher_background, getString(R.string.playground_description2)));
        place.add(new Place(getString(R.string.playground_name3), "weṭeṭṭi",  R.drawable.ic_launcher_background, getString(R.string.playground_description3)));


        PlaceAdapter adapter = new PlaceAdapter(getActivity(), place);


        ListView listview = (ListView) rootView.findViewById(R.id.list);

        listview.setAdapter(adapter);

        return rootView;
    }
}