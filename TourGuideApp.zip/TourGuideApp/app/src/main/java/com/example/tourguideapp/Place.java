package com.example.tourguideapp;

public class Place {

    private String mName;
    private String mLocation;
    private int mImageResourceId = NO_IMAGE_PROVIDED;
    private static final int NO_IMAGE_PROVIDED = -1;
    private String mDescription;
    private String mOpaningHours;

    public Place(String name, String location, String description){
        mName = name;
        mLocation = location;
        mDescription = description;
    }

    public Place(String name, String location, String openingHours, String description){
        mName = name;
        mLocation = location;
        mOpaningHours = openingHours;
        mDescription = description;
    }
    public Place(String name, String location, int imageResourceId, String description){
        mName = name;
        mLocation = location;
        mImageResourceId = imageResourceId;
        mDescription = description;
    }

    public String getmName() {
        return mName;
    }
    public String getmLocation() {
        return mLocation;
    }
    public String getmDescription() {
        return mDescription;
    }
    public String getmOpaningHours() {
        return mOpaningHours;
    }
    public int getmImageResourceId() {
        return mImageResourceId;
    }
    public boolean hasImage(){
        return (mImageResourceId != NO_IMAGE_PROVIDED);
    }

}
