package com.example.tourguideapp;
import android.content.Context;
import android.media.AudioManager;
import android.media.MediaPlayer;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.ListView;

import androidx.fragment.app.Fragment;

import java.util.ArrayList;

public class ParkFragment extends Fragment {

    public ParkFragment() {

    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
        View rootView =  inflater.inflate(R.layout.places_list, container, false);

        //create words arrayList
        final ArrayList<Place> place = new ArrayList<Place>();
        place.add(new Place(getString(R.string.park_name1), "weṭeṭṭi", R.drawable.ic_launcher_background, getString(R.string.park_description1)));
        place.add(new Place(getString(R.string.park_name2), "weṭeṭṭi", R.drawable.ic_launcher_background, getString(R.string.park_description2)));
        place.add(new Place(getString(R.string.park_name3), "weṭeṭṭi", R.drawable.ic_launcher_background, getString(R.string.park_description3)));


        PlaceAdapter adapter = new PlaceAdapter(getActivity(), place);


        ListView listview = (ListView) rootView.findViewById(R.id.list);

        listview.setAdapter(adapter);

        return rootView;
    }
}