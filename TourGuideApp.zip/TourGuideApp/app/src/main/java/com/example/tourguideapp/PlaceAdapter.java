package com.example.tourguideapp;

import android.app.Activity;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.core.content.ContextCompat;

import java.util.ArrayList;

public class PlaceAdapter extends ArrayAdapter<Place> {

    public PlaceAdapter(Activity context, ArrayList<Place> place) {
        super(context, 0, place);
    }

    @Override
    public View getView(int position, @Nullable View convertView, @NonNull ViewGroup parent) {
        View listItemView = convertView;
        if (listItemView == null) {
            listItemView = LayoutInflater.from(getContext()).inflate(
                    R.layout.single_place_item, parent, false);
        }

        final Place currentPlace = getItem(position);


        TextView nameTextView =(TextView) listItemView.findViewById(R.id.place_name);
        nameTextView.setText(currentPlace.getmName());

        TextView locationTextView =(TextView) listItemView.findViewById(R.id.location_name);
        locationTextView.setText(currentPlace.getmLocation());

        ImageView placeImageView = (ImageView) listItemView.findViewById((R.id.place_image));
        if(currentPlace.hasImage()){
            placeImageView.setImageResource(currentPlace.getmImageResourceId());
            placeImageView.setVisibility(View.VISIBLE);
        } else {
            placeImageView.setVisibility(View.GONE);
        }

        TextView descriptionTextView = (TextView) listItemView.findViewById(R.id.place_description);
        descriptionTextView.setText(currentPlace.getmLocation());

        return listItemView;
    }

}

